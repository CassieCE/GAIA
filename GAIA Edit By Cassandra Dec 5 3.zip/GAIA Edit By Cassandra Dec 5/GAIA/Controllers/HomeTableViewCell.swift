//
//  HomeTableViewCell.swift
//  PlantCareApp
//
//  Created by Michael Riewe on 2022-12-04.
//

import UIKit

class HomeTableViewCell: UITableViewCell {

    // outlets for cell
    @IBOutlet weak var plantNameLabel: UILabel!
    @IBOutlet weak var reminderDescriptionLabel: UILabel!

    // set the reminder in the tableView
    func setReminder(reminder: Reminder) {
        plantNameLabel.text = reminder.plant
        reminderDescriptionLabel.text = reminder.reminderDescription

    }
    
}
