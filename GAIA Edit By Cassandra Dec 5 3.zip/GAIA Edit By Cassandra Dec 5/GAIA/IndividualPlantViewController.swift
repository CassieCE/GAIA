//
//  IndividualPlantViewController.swift
//  PlantCareApp
//
//  Created by Cassandra Courchesne Evans on 2022-11-21.
//

import UIKit

class IndividualPlantViewController: UIViewController {

    
    // Outlets

    @IBOutlet weak var plantImageView: UIImageView!

    @IBOutlet weak var yourPlantTextView: UITextView!

    @IBOutlet weak var plantCareTips: UITextView!
    
//    //    local variables
//    var plantName: String = ""
//    var sunlight: String = ""
//    var watering: String = ""

//    override func viewDidLoad() {
//        super.viewDidLoad()
//        //Added a title to the nav bar
//        title = "Plant Info"
//        // Do any additional setup after loading the view.
//    }
//
////    Functions
//
////    Buttons
//
//    @IBAction func getPlantTips(_ sender: Any) {
//    }
 
  
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
