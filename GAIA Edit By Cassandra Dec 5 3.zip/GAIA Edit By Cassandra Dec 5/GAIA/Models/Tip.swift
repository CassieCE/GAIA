//
//  Tip.swift
//  PlantCareApp
//
//  Created by Michael Riewe on 2022-11-27.
//

import Foundation

class Tip {
    
    // global vars
    var tipTypes: [String] = ["Water", "Soil", "Light", "Other"]
    var plants = ["Plant 1", "Plant 2", "Plant 3", "Plant 4"]

    // properties
    var tipDescription: String
    var tipType: String
    var plantName: String?
//    var plant: Plant // TODO: pull plant from existing plant list
    
    // constructor for all properties
    init(tipDescription: String, tipType: String, plantName: String) {
        self.tipDescription = tipDescription
        self.tipType = tipType
        self.plantName = plantName
    }
    
    // constructor for required properties
    init(tipDescription: String, tipType: String) {
        self.tipDescription = tipDescription
        self.tipType = tipType
        self.plantName = nil
    }
    
    // methods
    
    
    // search all tips for filter button(s)
    public func sortByFilter(category: String) -> [Tip] {
        
        // initialize relatedTips array
        var relatedTips: [Tip] = []
        
        // get list of all tips
        // get list from database TODO: research how to conect to database and retrieve records, or retrieve from dummy flat file
        
        // iterate through list and find any that contain passed in filter keyword
        
        // if contains keyword, add to relatedTips[]
        
        // return all related tips (to the table view in Tips Controller)
        return relatedTips
    }
} // end class


