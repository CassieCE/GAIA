//
//  PlantCollectionViewController.swift
//  PlantCareApp
//
//  Created by Cassandra Courchesne Evans on 2022-11-21.
//

import UIKit

class PlantCollectionViewController: UIViewController, UITableViewDelegate,UITableViewDataSource {

   
    // Outlets
    
    //table view outlet
    @IBOutlet weak var tableView: UITableView!
    
    // cell table lable plant name outlet
    @IBOutlet weak var plantNameTextField: UITextField!
    
    //Enter plant sunlight text field outlet
    @IBOutlet weak var sunlightTextField: UITextField!
    
    //Enter water requirments text field outlet
    @IBOutlet weak var wateringTextField: UITextField!

    //Lable outlet - lets the user know if they have input invalid data
    @IBOutlet weak var textLable: UILabel!
    
    //Variables
    var plant = PlantCollection()
    
    
    

    //Create an array to hold the user plant Collection
    var plantCollection: [Plant] = []

    // List of options for sunlight requrments of a plant of given by pickerview
    var validSunlightOptionsList = ["Full sun", "Part sun", "Full shade", "Part shade"]
    
    // List of options for sunlight requrments of a plant of given by pickerview
    var validWateringOptionsList = ["Daily", "Every other day", "Weekly", "Monthly"]
    
    // pickerview  for sun values
    var sunlightPickerView = UIPickerView()
    
    // pickerview for water values
    var wateringPickerView = UIPickerView()
    
   
    override func viewDidLoad() {
        super.viewDidLoad()
        // loaded fake plant1 in to the plantCollection append to all reminders
        let plant1 = Plant(name: "Bob the plant", sun: "Full sun", water: "Daily", image: "plant.png")
        plantCollection.append(plant1)
//        
//        // sunlightPickerView - assign delagate to self
//        sunlightPickerView.delegate = self
//        //sunlightPickerView - datasoruce to self
//        sunlightPickerView.dataSource = self
//        //  selection to sunlight textfield
//       sunlightTextField.inputView = sunlightPickerView
//
//        // WateringPickerView - assign delagate to self
//        wateringPickerView.delegate = self
//        //wateringPickerView - datasoruce to self
//        wateringPickerView.dataSource = self
//        //  selection to wateringViewPicker textfield
//        wateringTextField.inputView = wateringPickerView
//
//        // assign delagate and datasource to self for collectionTableView
//        tableView.delegate = self
//        tableView.dataSource = self
//        
//    
 
    }// end of override function viewDidLoad
    
    // returns number of rows in the table
     func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
     return plantCollection.count
    } // end func tableview

   //This function returns a new plant cell
     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

         let plant = plantCollection[indexPath.row]
         let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! CollectionTableViewCell
         cell.createNewPlant(plant: plant)
    //returns the cell
        return cell
    } // end func tableView
        
        // returns a hight for the row to better fit the images
        func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            return 170
        }// end func tableView


    //Actions

    // Button actions
    

    
    // When the create button is pressed a new plant will be added to the collection in the table view
    @IBAction func createBtnPress(_ sender: UIButton) {

        let newPlantName = plantNameTextField.text
        let newSunlightRequirment = sunlightTextField.text
        let newWateringRequirment = wateringTextField.text

        if newPlantName!.isEmpty {
            let alert = UIAlertController(title: "Alert", message: "Please choose a plant name.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert, animated: true, completion: {return})
        } else if newSunlightRequirment!.isEmpty {
            let alert = UIAlertController(title: "Alert", message: "Please pick a valid sunlight for your little plant", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert, animated: true, completion: {return})
        } else {

            // Assign new data to a new Plant obeject
            let newPlant = Plant(name: newPlantName!, sun: newSunlightRequirment!, water: newWateringRequirment!, image: "plant.png")
            // append new plant object into the plantCollection array
            plantCollection.append(newPlant)
            // reload collectionTableview with new table cell
           tableView.reloadData()

            //Reset text in the TextFields
            plantNameTextField.text = ""
            sunlightTextField.text = ""
            wateringTextField.text = ""
        }
    }
    

    //
//    @IBAction func editBtnPress(_ sender: Any) {
//    }
//
//    //
//    @IBAction func removePlantBtnPress(_ sender: Any) {
//    }
//
    //Create a new plant collection to add as add plant objects
    let snakePlant = Plant(name: "Snake Plant", sun: "Full sun", water: "Daily", image: "snakePlant.jpg")
    let spiderPlant = Plant(name: "Spider Plant", sun: "Part sun", water: "Every other day", image: "spiderPlant.jpg")
    let peaceLily = Plant(name: "Peace Lily ", sun: "Full sun", water: "Daily", image: "peaceLily.jpg")
    let aloe = Plant(name: "Aloe", sun: "Full sun", water: "Every other day", image: "aloe.jpg")
    let rubberPlant = Plant(name: "Rubber Plant", sun: "Part sun", water: "Daily", image: "rubberPlant.jpg")
    
    // loaded fake plant1 data
    let plant1 = Plant(name: "Bob the plant", sun: "Full sun", water: "Daily", image: "plant.png")
 

      //navigation and sending data to IndividualPlantViewController local variables
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let individualVC: IndividualPlantViewController = self.storyboard?.instantiateViewController(withIdentifier: " IndividualPlantViewController") as!  IndividualPlantViewController
        
// assigning values to the local variable declared in IndividualPlantViewController Class
            individualVC.name = plantNameTextField.text!
            individualVC.sunlight = plant1.sun
            individualVC.watering = plant1.water
        
                // navigate to IndividualPlantViewController
            self.navigationController?.pushViewController(individualVC, animated: true)
            }
    

    
    } // end class


//Extension of the viewController to add Date pickers for sun and water requirments
extension PlantCollectionViewController: UIPickerViewDelegate, UIPickerViewDataSource {
    // Create pickerview values for the sunlightPickerView
    
    // get number of components to use
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    // get number of items in  validSunlightOptionsList  array
    func pickerView1(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return  validSunlightOptionsList.count
    }
    
    // Return each item frome the validSunlightOptionsList in the pickerview
    func pickerView1(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return  validSunlightOptionsList [row]
    }
    
    // when selected, display value in textfield
    func pickerView1(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        sunlightTextField.text =  validSunlightOptionsList[row]
        sunlightTextField.resignFirstResponder()
    }
    
    // Create pickerview values for wateringPickerView
    
    // get number of items in  validWateringOptionsList  array
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return  validWateringOptionsList.count
    }
    
    // Return each item frome the validWateringOptionsListin the pickerview
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return  validWateringOptionsList [row]
    }
    
    // when selected, display value in textfield
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        wateringTextField.text =  validWateringOptionsList[row]
        wateringTextField.resignFirstResponder()
        
    }
}



