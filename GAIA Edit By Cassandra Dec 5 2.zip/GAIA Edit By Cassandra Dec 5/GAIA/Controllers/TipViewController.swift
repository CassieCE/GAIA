//
//  TipViewController.swift
//  GAIA
//
//  Created by Michael Riewe on 2022-11-07.

import UIKit

class TipViewController: UIViewController {
    
    // outlets
    
    
    @IBOutlet weak var tipsTableView: UITableView!
    
    // create array to hold tips
    var allTips: [Tip] = []
    // call objects from JSON file
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // assign delagate and datasource to self for tableView
        tipsTableView.delegate = self
        tipsTableView.dataSource = self
        
        allTips = rebuildTips()
        
    }
    
    @IBAction func tipWaterButton(_ sender: Any) {
        
        allTips = rebuildTips()
        
        var tempTips: [Tip] = []
        
        for tip in allTips {
            if tip.tipType == "Water" {
                tempTips.append(tip)
            }
        }
        
        allTips = tempTips
        tipsTableView.reloadData()
        
    }
    
    @IBAction func tipSoilButton(_ sender: Any) {

        allTips = rebuildTips()

        var tempTips: [Tip] = []
        
        for tip in allTips {
            if tip.tipType == "Soil" {
                tempTips.append(tip)
            }
        }
        
        allTips = tempTips
        tipsTableView.reloadData()
        
    }
    
    @IBAction func tipLightButton(_ sender: Any) {
        
        allTips = rebuildTips()

        var tempTips: [Tip] = []
        
        for tip in allTips {
            if tip.tipType == "Light" {
                tempTips.append(tip)
            }
        }
        
        allTips = tempTips
        tipsTableView.reloadData()
    
    }
    
    @IBAction func tipOtherButton(_ sender: Any) {
        
        allTips = rebuildTips()

        var tempTips: [Tip] = []
        
        for tip in allTips {
            if tip.tipType == "Other" {
                tempTips.append(tip)
            }
        }
        
        allTips = tempTips
        tipsTableView.reloadData()
    
    }
    
    @IBAction func tipResetButton(_ sender: Any) {
        
        allTips = rebuildTips()
        tipsTableView.reloadData()
        
    }
    // rebuild dummy tips
    func rebuildTips() -> [Tip] {
        var allTips: [Tip] = []
        
        // create dummy data for tableview
        let tip1 = Tip(tipDescription: "Water every day", tipType: "Water")
        let tip2 = Tip(tipDescription: "Arid soil is best Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat", tipType: "Soil")
        let tip3 = Tip(tipDescription: "Light by windowsill for many plants", tipType: "Light", plantName: "Plant 1")

        allTips.append(tip1)
        allTips.append(tip2)
        allTips.append(tip3)
        
        return allTips
    }
    
    
}

// for creating and adding tips
extension TipViewController: UITableViewDelegate, UITableViewDataSource {
    
    // get number of rows to display from allReminders
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return allTips.count
    }
    
    // create and display each cell in allReminders
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let tip = allTips[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "TipCell") as! TipTableViewCell
        cell.setTip(tip: tip)
        return cell
    }
    
} // end extension
