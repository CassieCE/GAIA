//
//  Reminders.swift
//  PlantCareApp
//
//  Created by Michael Riewe on 2022-11-27.
//
import Foundation


class Reminder {
    
    // properties
    var reminderName: String?
    var reminderDescription: String
    var reminderDate: Date
    var recurringReminder: Bool
    var recurringDays: Int?
    var plant: String
//    var plant: Plant // TODO: get plant.name from plant object
    
        
    // constructor for all properties
    init(reminderName: String, reminderDescription: String, reminderDate: Date, recurringReminder: Bool, recurringDays: Int, plant: String ) {
        self.reminderName = reminderName
        self.reminderDescription = reminderDescription
        self.reminderDate = reminderDate
        self.recurringReminder = recurringReminder
        self.recurringDays = recurringDays
        self.plant = plant
    }
    
    // constructor for required properties
    init(reminderDescription: String, plant: String, reminderDate: Date) {
        self.reminderName = nil
        self.reminderDescription = reminderDescription
        self.reminderDate = reminderDate
        self.recurringReminder = true // defaults to recurring true
        self.recurringDays = 3 // defaults to tend to plant every 3 days
        self.plant = plant
    }
    
    // methods
   
    // create reminder
    // on ReminderViewController
       
    // sort by date
    public func sortRemindersByDate(sortDate: String) -> [Reminder] {
        
        // init array for Reminders // OR get array from reminderVC
        var sortedReminders: [Reminder] = []
        
        // get list of all reminders set and add to array
        
        // get list from database TODO: research how to conect to database and retrieve records, or retrieve from dummy flat file
        
        // sort chronologically
        
        // return list
        return sortedReminders
    }
    
    // daily reminder notification
    
    public func pushDailyReminders() -> [Reminder] {
        
        // init array for Reminders
        var dailyReminders: [Reminder] = []
        
        // get today's date
        
        // if reminderDate matches today's date, add to array
        
        // return array list
        return dailyReminders
    }
    
}
