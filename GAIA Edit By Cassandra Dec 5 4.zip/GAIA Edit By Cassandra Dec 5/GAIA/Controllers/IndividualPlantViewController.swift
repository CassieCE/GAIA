//
//  IndividualPlantViewController.swift
//  PlantCareApp
//
//  Created by Cassandra Courchesne Evans on 2022-11-21.
//

import UIKit

class IndividualPlantViewController: UIViewController {

    
    // Outlets

    @IBOutlet weak var plantNameLabel: UILabel!// Plant Name label
    

    @IBOutlet weak var plantImageView: UIImageView!// plant ImageView

    
    @IBOutlet weak var yourPlantTextView: UITextView!// Text View
    
    @IBOutlet weak var sunTextLabel: UILabel!// Text label for sun requierments
    
    @IBOutlet weak var waterTextLabel: UILabel!// Text label for Water requierments
    
    //Creating a plant from plant class
    let plant1 = Plant(name: "Spider Plant", sun: "Part sun", water: "Every other day", image: "spiderPlant.jpg")
    //    local variables
    var name: String = ""
    var sunlight: String = ""
    var watering: String = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        //Added a title to the nav bar
        title = "Plant Details"
        // Do any additional setup after loading the view.
        plant1.name = name
        plant1.sun = sunlight
        plant1.water = watering
       
        sunlight = sunTextLabel.text!
        watering = waterTextLabel.text!
       
        
    }

//    Functions

//    Buttons
// go to reminders page
    @IBAction func goToRminders(_ sender: Any) {
    }
    //go to tips for plants with this name
    @IBAction func plantTips(_ sender: Any) {
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
