//
//  ReminderTableViewCell.swift
//  GAIA
//
//  Created by Michael Riewe on 2022-11-27.
//

import UIKit

class ReminderTableViewCell: UITableViewCell {
    
    // outlets
    
    @IBOutlet weak var plantNameLabel: UILabel!
    @IBOutlet weak var reminderDateLabel: UILabel!
    @IBOutlet weak var reminderDescriptionLabel: UILabel!
    
    // generic function to convert date to string format
    func convertDateToString(date: Date) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MMM d, yyyy"
        return dateFormatter.string(from: date)
    }
    
    // set the reminder in the tableView
    func setReminder(reminder: Reminder) {
        plantNameLabel.text = reminder.plant
        reminderDescriptionLabel.text = reminder.reminderDescription

        reminderDateLabel.text = convertDateToString(date: reminder.reminderDate)
    }
    
    

}
