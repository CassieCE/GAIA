//
//  ReminderViewController.swift
//  GAIA
//
//  Created by Michael Riewe on 2022-11-07.
//
import UIKit

class ReminderViewController: UIViewController {

    @IBOutlet weak var reminderTableView: UITableView!
    @IBOutlet weak var plantSelectionTextField: UITextField!
    @IBOutlet weak var reminderDescriptionTextField: UITextField!
    @IBOutlet weak var reminderDatePicker: UIDatePicker!

    // create array to hold reminders
    var allReminders: [Reminder] = []
    
    // create dummy list of plants to use in pickerview
    // TODO: connect to DB/flat file and pull objects
    var plantList = ["Living Room Plant 1", "Living Room Plant 2", "Bedroom Plant 1", "Kitchen Plant 1", "Living Room Plant 3"]
    // create pickerview to populate plant name in reminder
    var plantPickerView = UIPickerView()
    
    // button for set reminder
    @IBAction func setReminder(_ sender: UIButton) {
        
        let newPlant = plantSelectionTextField.text
        let newDescription = reminderDescriptionTextField.text
        let newDate = reminderDatePicker.date
        
        if newPlant!.isEmpty {
            let alert = UIAlertController(title: "Alert", message: "You must choose a plant", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert, animated: true, completion: {return})
        } else if newDescription!.isEmpty {
            let alert = UIAlertController(title: "Alert", message: "You must enter a description", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert, animated: true, completion: {return})
        } else {
            
            // pass new data to new obeject
            let newReminder = Reminder(reminderDescription: newDescription!, plant: newPlant!, reminderDate: newDate)
            // add reminder object to array
            allReminders.append(newReminder)
            // reload the tableview with new object appended
            reminderTableView.reloadData()
            
            // reset text fields
            plantSelectionTextField.text = ""
            reminderDescriptionTextField.text = ""
            reminderDatePicker.date = Date()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // assign delagate and datasoruce to self for plantPickerView
        plantPickerView.delegate = self
        plantPickerView.dataSource = self
        // send selection to text field in view
//        plantSelectionTextField.inputView? = plantPickerView
//
//        // assign delagate and datasource to self for tableView
//        reminderTableView.delegate = self
//        reminderTableView.dataSource = self

        // create example reminders and append to all reminders
        let reminder1 = Reminder(reminderName: "Reminder 1 name", reminderDescription: "Reminder 1 description", reminderDate: Date(), recurringReminder: true, recurringDays: 3, plant: "Plant 1")
        allReminders.append(reminder1)
        let reminder2 = Reminder(reminderName: "Reminder 2 name", reminderDescription: "Reminder 2 description", reminderDate: Date(), recurringReminder: true, recurringDays: 2, plant: "Plant 2")
        allReminders.append(reminder2)

    }
    
    // add functions to swipe to remove reminders
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            allReminders.remove(at: indexPath.row)
            reminderTableView.deleteRows(at: [indexPath], with: .fade)
        }
    }
}

// for creating and adding reminders
extension ReminderViewController: UITableViewDelegate, UITableViewDataSource {
    
    // get number of rows to display from allReminders
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return allReminders.count
    }
    
    // create and display each cell in allReminders
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let reminder = allReminders[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! ReminderTableViewCell
        cell.setReminder(reminder: reminder)
        return cell
    }
} // end extension


// add pickerview code for choosing plant name
extension ReminderViewController: UIPickerViewDelegate, UIPickerViewDataSource {
    
    // get number of components to use
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    // get number of items to display from array/objects in DB
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return plantList.count
    }
    
    // display the name of each item in pickerview list
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return plantList[row]
    }
    
    // when selected, display value in textfield
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        plantSelectionTextField.text = plantList[row]
        plantSelectionTextField.resignFirstResponder()
    }
} // end extension
