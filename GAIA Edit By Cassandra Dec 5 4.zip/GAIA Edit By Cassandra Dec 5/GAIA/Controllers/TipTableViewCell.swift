//
//  TipTableViewCell.swift
//  GAIA
//  Created by Michael Riewe on 2022-11-27.
//

import UIKit

class TipTableViewCell: UITableViewCell {
    
    // outlets for tips cell
    @IBOutlet weak var tipDescription: UILabel!
    @IBOutlet weak var appliesToPlantLabel: UILabel!
    @IBOutlet weak var tipTypeLabel: UILabel!
        // set the tip in the tableView
    func setTip(tip: Tip) {
        tipDescription.text = tip.tipDescription
        appliesToPlantLabel.text = tip.plantName
        tipTypeLabel.text = tip.tipType
    }

}
