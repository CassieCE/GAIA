//
//  HomeViewController.swift
//  GAIA
//
//  Created by Michael Riewe on 2022-11-07.
//

import UIKit
import MapKit

class HomeViewController: UIViewController {
    
    // outlets

    @IBOutlet weak var homeTableView: UITableView!

    @IBOutlet weak var mapView: MKMapView!

    // add array for today's reminders
    var todayReminders: [Reminder] = []
    var allReminders: [Reminder] = []
    // initialize a map coordinates
    var locationCoordinates:CLLocationCoordinate2D = CLLocationCoordinate2D.init(latitude: 0, longitude: 0)


    override func viewDidLoad() {
        super.viewDidLoad()

        // create example reminders and append to all reminders, various dates
        let reminder1 = Reminder(reminderName: "Reminder 1 name", reminderDescription: "Reminder 1 description", reminderDate: Date().addingTimeInterval(432000), recurringReminder: true, recurringDays: 3, plant: "Plant 1")
        let reminder2 = Reminder(reminderName: "Reminder 2 name", reminderDescription: "Reminder 2 description", reminderDate: Date(), recurringReminder: true, recurringDays: 2, plant: "Plant 2")
        allReminders.append(reminder1)
        allReminders.append(reminder2)

        // get todays date and format it to compare against stored value
        let todayDate = convertDateToString(date: Date())

        func convertDateToString(date: Date) -> String {
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "MMM d, yyyy"
            return dateFormatter.string(from: date)
        }

        // compare date set in reminder ad return only today's remoinders
        for reminder in allReminders {
            if convertDateToString(date: reminder.reminderDate) == todayDate {
                todayReminders.append(reminder)
            }
        }

        // assign delagate and datasource to self for tableView
        homeTableView.delegate = self
        homeTableView.dataSource = self

        // add map coordinates
        addLocation(latCoord: 44.4116, longCoord: -79.6667, title: "My Home")
        addLocation(latCoord: 44.33307, longCoord: -79.68656, title: "My Office")
    }

    // function for setting points on map
    private func addLocation(latCoord: Double, longCoord: Double, title: String)
    {
        // create a locationa and set coordinates
        locationCoordinates = CLLocationCoordinate2DMake(latCoord, longCoord)
        // set map zoom area
        let locationSpan = MKCoordinateSpan(latitudeDelta: 0.3, longitudeDelta: 0.2)
        let locationRegion = MKCoordinateRegion(center: locationCoordinates, span: locationSpan)
        mapView.setRegion(locationRegion, animated: true)
        // create an annotation and add it to map location
        let annotation = MKPointAnnotation()
        annotation.coordinate = locationCoordinates
        // add title to annotation and set it to the map
        annotation.title = title
        mapView.addAnnotation(annotation)
    }
}

extension HomeViewController: UITableViewDelegate, UITableViewDataSource {

    // get number of rows to display from todayReminders
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return todayReminders.count
    }

    // create and display each cell in todayReminders
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let reminder = todayReminders[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! HomeTableViewCell
        cell.setReminder(reminder: reminder)
        return cell
    }

} // end extension
