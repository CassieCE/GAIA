//
//  CollectionTableViewCell.swift
//  GAIA
//
//  Created by Cassandra Courchesne Evans on 2022-11-30.
//

import UIKit

class CollectionTableViewCell: UITableViewCell {
    
//    outlets
    
    //table cell outlet
    @IBOutlet weak var collectionTableCell: UITableView!
    //cell image outlet
    @IBOutlet weak var tableCellImage: UIImageView!
   
    //cell plant Name lable outlet
    @IBOutlet weak var tableCellLabel: UILabel!
    
 
    // create a new plant in the collectionTableView
    func createNewPlant(plant: Plant) {
        
        tableCellLabel.text = plant.name

        tableCellImage.image = UIImage(named: plant.image )//("plant.png")
    }
    

//    override func awakeFromNib() {
//        super.awakeFromNib()
//        // Initialization code
//    }
//
//    override func setSelected(_ selected: Bool, animated: Bool) {
//        super.setSelected(selected, animated: animated)
//
//        // Configure the view for the selected state
//    }

}
