//
//  Plant.swift
//  PlantCareApp
//
//  Created by Cassandra Courchesne Evans on 2022-11-30.
//
//This Plant class has the same four private variables as the previous example: name, sun, water, and image. However, the "set" functions for these variables now include validation to ensure that the values being set are valid.

//References for images used
//Aloe vera - Photo by pisauikan on Unsplash
//Snake plant - Photo by Sarah Bronske on Unsplash
//Spider plant - Photo by おにぎり on Unsplash
//Peace lily - Photo by Antonia Kofod on Unsplash
//Rubber plant - Photo by Elle Lumière on Unsplash

import Foundation

// class Plant
class Plant {
    //Class variables
   
    var name: String //plant name
    var sun: String  //plant sunlight requirments
    var water: String//plant water requirments
    var image: String//plant image
    
    // init constructor for all the variables
    init(name: String, sun: String, water: String, image: String) {
        //init the variables
        self.name = name
        self.sun = sun
        self.water = water
        self.image = image
    }// end of init
    

    
    
    //    This is used to get tips based on cases of plant names
        enum Plant{ case Plant1, Plant2, Plant3, Plant4, Plant5 }
    
//The setName function checks if the value given by the user is an empty.
    // If it is, the value is assigned to the sun variable. Otherwisethe plant name will be set to "Unknown".
  func setName(name: String) {
    if name.isEmpty {
      self.name = "Unknown"
    } else {
      self.name = name
    }
  }//end of set name

// Returns name variable
  func getName() -> String {
    return self.name
  }//end of get name
                                                                                                                                                
//For the sun variable, the setSun function first defines an array of valid sunlight values:
//    ["Full sun", "Part sun", "Full shade","Part shade"].
// It then checks if the value being passed is contained in this array.
// If it is, the value is assigned to the sun variable. Otherwise, the sun variable is set to "Unknown".
  func setSun(sun: String) {
    let validSunlight = ["Full sun", "Part sun", "Full shade", "Part shade"]
    if validSunlight.contains(sun) {
      self.sun = sun
    } else {
      self.sun = "Unknown"
    }
  }//end of set sun func
                                                                                                                                       
// Returns sun variable
  func getSun() -> String {
    return self.sun
  }//end of get sun func
    
    
//This function defines an array of valid watering frequencies: ["Daily", "Every other day", "Weekly", "Monthly"].
// If the value entered is contained in this array it will set the water variable.
// Otherwise, the water variable is set to "Unknown".
  func setWater(water: String) {
    let validFrequencies = ["Daily", "Every other day", "Weekly", "Monthly"]
    if validFrequencies.contains(water) {
      self.water = water
    } else {
      self.water = "Unknown"
    }
  }
                                                                                                                                                
// Returns water variable
  func getWater() -> String {
    return self.water
  }//end of get water func
    
//This function checks if the value being passed is an empty string.
//If it is, the image variable is set to "default.jpg".
//Otherwise, the value is assigned to the image
  func setImage(image: String) {
    if image.isEmpty {
      self.image = "plant.png"
    } else {
      self.image = image
    }
  }
                                                                                                                        
    
// Returns image
  func getImage() -> String {
    return self.image
  }//end of get image
    

//    enum PlantTips {
//      case snakePlant
//      case spiderPlant
//      case peaceLily
//      case aloe
//      case rubberPlant
//    }// end of enum
//
}//end class
    

    





