//
//  Collections.swift
//  GAIA
//
//  Created by Cassandra Courchesne Evans on 2022-11-30.

import Foundation

//PlantCollection class holds an array Plant objects.
class PlantCollection{
  var plants: [Plant]
    
    
//    The initializer takes an array of Plant objects as an argument and assigns it to the plants property.
    // Initialize an empty collection of house plants
       init() {
           self.plants = [Plant]()
       }

    
    
    // Add a plant to the collection
       func add(plant: Plant) {
           self.plants.append(plant)
       }

//       // Remove a plant from the collection
//       func remove(plant: Plant) {
//           if let index = self.plants.index(of: plant) {
//               self.plants.remove(at: index)
//           }
//       }

       // Get a plant from the collection by its index
       func get(index: Int) ->Plant? {
           if index >= 0 && index < self.plants.count {
               return self.plants[index]
           }
           return nil
       }

       // Print the names of all the plants in the collection
       func call() {
           for plant in self.plants {
               print(plant.name)
           }
       }

    
}//End Of Class



//
////Create a new plant collection and add plant objects
//let snakePlant = Plant(name: "Snake Plant", sun: "Full sun", water: "Daily", image: "snakePlant.jpg")
//let spiderPlant = Plant(name: "Spider Plant", sun: "Part sun", water: "Every other day", image: "spiderPlant.jpg")
//let peaceLily = Plant(name: "Peace Lily ", sun: "Full sun", water: "Daily", image: "peaceLily.jpg")
//let aloe = Plant(name: "Aloe", sun: "Full sun", water: "Every other day", image: "aloe.jpg")
//let rubberPlant = Plant(name: "Rubber Plant", sun: "Part sun", water: "Daily", image: "rubberPlant.jpg")
////
////let PlantCollection = PlantCollection(plants: [snakePlant, spiderPlant, peaceLily, aloe, rubberPlant])
//
////let collection = PlantCollection()
//
//let plant1 = Plant(name: "Peace Lily", sun: "Full Shade", water: "Weekly", image: "peace-lily.jpg")
//
////collection.add(plant: plant1)






